package com.example.githubapp

data class DetailItem (
    val login: String,
    val id: Int,
    val avatar_url: String,
    val name: String,
    val followers: Int,
    val followinf:Int
        )